Aaram font
----------

Thank you for downloading this font.

More awesome freemium and premium stuff are at http://gumroad.com/enathu

Thank you very much.

Tharique Azeez
Niram Factory
http://twitter.com/enathu

